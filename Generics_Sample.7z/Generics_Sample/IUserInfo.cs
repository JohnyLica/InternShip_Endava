﻿namespace Generics_Sample
{
    public interface IUserInfo
    {
        string Name { get; set; }
        int Age { get; set; } 
    }
}